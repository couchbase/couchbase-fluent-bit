pycrc-0.9.2/pycrc.py --generate c --algorithm table-driven --model crc-32 --slice-by 8 -o crc32.c
pycrc-0.9.2/pycrc.py --generate h --algorithm table-driven --model crc-32 --slice-by 8 -o crc32.h
