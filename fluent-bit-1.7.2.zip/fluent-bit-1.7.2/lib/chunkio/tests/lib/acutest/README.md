Taken from https://github.com/mity/acutest

MIT License

